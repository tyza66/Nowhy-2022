var page = new Vue({
    el:"#page",
    data:{
        yixuan: 0,
        char1:"char",
        char2:"char",
        char3:"char",
        char4:"char",
        char5:"char",
        char6:"char",
        char7:"char",
        char8:"char",
        char9:"char",
        char10:"char",
        char11:"char",
        char12:"char",
        char13:"chargreen",
        char14:"charred",
        char15:"chargreen",
        char16:"chargreen",
        char17:"char",
        char18:"char",
        char19:"char",
        char20:"char",
        char21:"char",
        char22:"char",
        char23:"char",
        char24:"char"
    },
    methods: {
        ch1(){
            if(this.char1=="char")
            {
               this.char1 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char1 = "char"
                this.yixuan--;
            }
            
        },
        ch2(){
            if(this.char2=="char")
            {
               this.char2 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char2 = "char"
                this.yixuan--;
            }
        },
        ch3(){
            if(this.char3=="char")
            {
               this.char3 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char3 = "char"
                this.yixuan--;
            }
        },
        ch4(){
            if(this.char4=="char")
            {
               this.char4 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char4 = "char"
                this.yixuan--;
            }
        },
        ch5(){
            if(this.char5=="char")
            {
               this.char5 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char5 = "char"
                this.yixuan--;
            }
        },
        ch6(){
            if(this.char6=="char")
            {
               this.char6 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char6 = "char"
                this.yixuan--;
            }
        },
        ch7(){
            if(this.char7=="char")
            {
               this.char7 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char7 = "char"
                this.yixuan--;
            }
        },
        ch8(){
            if(this.char8=="char")
            {
               this.char8 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char8 = "char"
                this.yixuan--;
            }
        },
        ch9(){
            if(this.char9=="char")
            {
               this.char9 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char9 = "char"
                this.yixuan--;
            }
        },
        ch10(){
            if(this.char10=="char")
            {
               this.char10 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char10 = "char"
                this.yixuan--;
            }
        },
        ch11(){
            if(this.char11=="char")
            {
               this.char11 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char11 = "char"
                this.yixuan--;
            }
        },
        ch12(){
            if(this.char12=="char")
            {
               this.char12 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char12 = "char"
                this.yixuan--;
            }
        },
        ch13(){
            alert("此座位已占");
        },
        ch14(){
            alert("此座位暂停使用");
        },
        ch15(){
            alert("此座位已占");
        },
        ch16(){
            alert("此座位已占");
        },
        ch17(){
            if(this.char17=="char")
            {
               this.char17 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char17 = "char"
                this.yixuan--;
            }
        },
        ch18(){
            if(this.char18=="char")
            {
               this.char18 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char18 = "char"
                this.yixuan--;
            }
        },
        ch19(){
            if(this.char19=="char")
            {
               this.char19 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char19 = "char"
                this.yixuan--;
            }
        },
        ch20(){
            if(this.char20=="char")
            {
               this.char20 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char20 = "char"
                this.yixuan--;
            }
        },
        ch21(){
            if(this.char21=="char")
            {
               this.char21 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char21 = "char"
                this.yixuan--;
            }
        },
        ch22(){
            if(this.char22=="char")
            {
               this.char22 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char22 = "char"
                this.yixuan--;
            }
        },
        ch23(){
            if(this.char23=="char")
            {
               this.char23= "charon" 
               this.yixuan++;
            }
            else
            {
                this.char23 = "char"
                this.yixuan--;
            }
        },
        ch24(){
            if(this.char24=="char")
            {
               this.char24 = "charon" 
               this.yixuan++;
            }
            else
            {
                this.char24 = "char"
                this.yixuan--;
            }
        },
        ti(){
            alert("提交成功！");
        }
}
})

