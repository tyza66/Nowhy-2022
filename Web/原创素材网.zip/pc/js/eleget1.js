var search1 = document.getElementById('sear')
search1.onclick  = function() {
    alert("az");
}