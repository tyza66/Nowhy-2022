package gh;

public interface Swimmable {
	void swim();
}
