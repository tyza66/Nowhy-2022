package gh;

public interface Flyable {
	void fly();
}
