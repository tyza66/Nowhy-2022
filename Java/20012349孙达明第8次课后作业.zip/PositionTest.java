package dasdfsadsadsad;

public class PositionTest {
	public static void main(String[] args) {
		Position a = new Position(2,3);
		Position b = new Position(3,4);
		System.out.println(a.compareTo(b));
		System.out.println(b.compareTo(a));
	}
}
