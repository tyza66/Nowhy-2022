package bao;

import java.util.Scanner;

public class CircleTest {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);
		System.out.printf("�뾶��");
		double b = a.nextDouble();
		System.out.printf("����ǣ�%.2f",b*b*Math.PI);
	}

}
